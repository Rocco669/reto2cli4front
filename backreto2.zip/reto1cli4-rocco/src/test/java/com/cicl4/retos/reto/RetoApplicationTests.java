package com.cicl4.retos.reto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
